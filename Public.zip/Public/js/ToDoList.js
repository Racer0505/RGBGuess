
$(".list").on("click",".inside",function(){
$(this).toggleClass("completed");
});

$(".list").on("click","span",function(event){
$(this).parent().fadeOut(500,function(){
$(this).remove();
})
event.stopPropagation();
});

$("input:text").on("keypress",function(event){
	
if(event.which==13){
	var text = $(this).val();
	$("div.list").append("<div class=inside> <span class ='icon mr-2'> <i class='fas fa-trash-alt ' style = 'color: white'></i> </span>" +  text +"</div>")
	var text = $(this).val("");
	
}
});


$(".plus").on("click",function(){
$("input:text").fadeToggle(500)
});

